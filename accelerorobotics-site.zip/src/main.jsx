import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import Accelerorobotics from './pages/Accelerorobotics'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Accelerorobotics />
  </React.StrictMode>
)
